package uk.ac.tees.L1087591;

/**
 * <p>WebPage represents a web page that has an id, url, source and date.
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */

import android.util.Log;

public class WebPage {

	/**
	 * id represent the id of the table.
	 */
	private int ID;

	/**
	 * url represent the url of the web page.
	 */
	private String url;

	/**
	 * source represent the content of the web page.
	 */
	private String source;

	/**
	 * date represent the last date the url was visited
	 */
	private long date;
	


	/**
	 * WebPage() creates a web page object
	 * 
	 * @param url
	 *            set the current url with the passed one.
	 * @param source
	 *            set the current source with the passed one.
	 * @param date
	 *            set the current date with the passed one.
	 */
	public WebPage(int id, String url, String source, long date) {
		this.ID = id;
		this.url = url;
		this.source = source;
		this.date = date;	
		Log.d("WebOff", "WebPage object created");
	}

	/**
	 * getID() gets the id of the web page.
	 * 
	 * @return the id
	 */
	public int getID() {
		return ID;
	}

	/**
	 * setItd() sets the id of the web page.
	 * 
	 * @param id
	 *            sets current id with the passed one.
	 */
	public void setId(int id) {
		this.ID = id;
	}

	/**
	 * getUrl() gets the url of the web page.
	 * 
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * setUrl() sets the url of the web page.
	 * 
	 * @param url
	 *            sets current Url with the passed one.
	 */
	public void setUrl(String url) {

		this.url = url;
	}

	/**
	 * getSource() gets the source of the web page.
	 * 
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * setSource() sets the source of the web page.
	 * 
	 * @param source
	 *            sets the current source with the passed one.
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * getDate() gets the date.
	 * 
	 * @return the date
	 */
	public long getDate() {
		return date;
	}

	/**
	 * setDate() sets the date.
	 * 
	 * @param date
	 *            sets the current date with the passed one.
	 */
	public void setDate(long date) {
		this.date = date;
	}

	/**
	 * webPage() prints the url/source/date for testing purposes.
	 */
	public void webPage() {
		Log.d("Debug", "" + this.url);
		Log.d("Debug", this.source);
		Log.d("Debug", this.date + "");
	}

	@Override
	public String toString() {
		return "WebPage [id=" + ID + ", url=" + url + ", source=" + source
				+ ", date=" + date + "]";
	}

}
