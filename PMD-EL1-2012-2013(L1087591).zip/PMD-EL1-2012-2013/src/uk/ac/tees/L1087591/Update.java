package uk.ac.tees.L1087591;

/**
 * <p>Update represent the update functionality of the MenuActivity. It allows to update the content of the WebPages if there is difference beetwen the the database and the WebSite</p>
 *
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Update extends MenuActivity {

	/**
	 * bar is used to display the download of the updates.
	 */
	private ProgressBar bar;

	/**
	 * dh makes a connection with the data base.
	 */
	private DatabaseHandler dh;

	/**
	 * countDifferentPages is responsible for counting the web pages from the db
	 * that have different content from the HTTP one.
	 */
	private int countDifferentPages = 0;

	/**
	 * btn starts the asynctask when clicked.
	 */
	Button btn;

	/**
	 * txt indicated when the updaing finish.
	 */
	TextView txt;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_update);
		btn = (Button) findViewById(R.id.button2);
		bar = (ProgressBar) findViewById(R.id.progressBar1);
		btn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				updatePages();
			}
		});

	}

	private class LongOperation extends
			AsyncTask<List<WebPage>, Integer, String> {

		@Override
		protected String doInBackground(List<WebPage>... params) {
			String url = "";
			String content = "";

			for (WebPage lr : params[0]) {
				url = lr.getUrl();
				content = lr.getSource();
				String webContent = urlToString(url);
				if (!content.equalsIgnoreCase(webContent)) {
					countDifferentPages++;
					Log.d("Database: ",
							"There has been a different content of the page: "
									+ lr.getUrl());
					lr.setSource(webContent);
					Log.d("New Content of the Web Page: ", lr.getSource());
					long date = System.currentTimeMillis();
					lr.setDate(date);
					Log.d("New Date: ", lr.getDate() + "");
					dh.updateWebPage(lr);
				}
			}

			Log.d("Database: ", "There were " + countDifferentPages
					+ " updates");
			Log.d("WebOff", "Database successfully updated");
			Log.d("Update ", "Updating button pressed..");
			return null;
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			bar.setProgress(values[0]);
		}

		@Override
		protected void onPostExecute(String result) {
			txt = (TextView) findViewById(R.id.textView1);
			txt.setText("Executed"); // txt.setText(result);
			// might want to change "executed" for the returned string passed
			// into onPostExecute() but that is upto you
		}

		@Override
		protected void onPreExecute() {
		}

		/**
		 * urlToString() take an URL and returns the content of the web page.
		 * 
		 * @param address
		 *            is the URL address
		 * @return the content of the URL address.
		 */
		private String urlToString(String address) {
			HttpURLConnection con = null;
			URL url;
			InputStream is = null;
			try {
				url = new URL(address);
				con = (HttpURLConnection) url.openConnection();
				con.setReadTimeout(10000);
				con.setConnectTimeout(15000);
				con.setRequestMethod("GET");
				con.connect();
				is = con.getInputStream();
			} catch (IOException e) {
				e.printStackTrace();
			}

			BufferedReader reader = null;
			StringBuilder sb = new StringBuilder();
			try {
				reader = new BufferedReader(new InputStreamReader(is));
				String line = "";
				int progress = 0;
				int lenght = con.getContentLength();
				while ((line = reader.readLine()) != null) {
					sb.append(line);
					// Log.d("Content", line);
					progress = (int) (sb.toString().length() * 100) / lenght;
					publishProgress(progress);
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (is != null) {
					try {
						is.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return sb.toString();
		}

		/**
		 * context object of type Context.
		 */
		private Context context;

		/**
		 * setContext() sets the current context with the passed one.
		 * 
		 * @param context
		 *            sets the context
		 */
		public void setContext(Context context) {
			this.context = context;
		}

	}

	/**
	 * updatePages() is responsible for executing the LongOperation private
	 * class.
	 */
	public void updatePages() {
		dh = new DatabaseHandler(this);
		Log.d("Database: ", "Updating the Database..");
		List<WebPage> list = dh.getAll();
		LongOperation op = new LongOperation();
		op.setContext(this);
		op.execute(list);
	}

}
