package uk.ac.tees.L1087591;

/**
 * <p>Add represent the add functionality of the MenuActivity.</p>
 *
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Add extends MenuActivity {

	/**
	 * submit is a the button for adding a web site.
	 */
	private Button submit;
	
	/**
	 * editText is where we get the web site from.
	 */
	private EditText editText;
	
	/**
	 * contents represent the contents of the edit Text.
	 */
	private String contents;
	
	/**
	 * dh is an ojbect of DatabaseHandler which makes the connetction of the data base.
	 */
	private DatabaseHandler dh;
	
	/**
	 * countIds count the number of Ids as required for the id of new web page in Add.java
	 */
	protected  int countIds;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        
        dh = new DatabaseHandler(this);
        submit = (Button) findViewById(R.id.button1);
        editText = (EditText) findViewById(R.id.editText1);
        
        
        //get the id for the next web page
        List<WebPage> list = dh.getAll();
		for (WebPage lr : list) {
			Log.d("Database ID ", countIds++ + "");
		}
        
        
        
        //when the submit button is clicked
        submit.setOnClickListener(new OnClickListener()
        {
        	public void onClick(View v)
        	{
        		Log.d("Submit"," Pressed");
        		try {
					URL url = new URL(editText.getText().toString());
					 contents = urlToString(editText.getText().toString());
	        		 Long date = System.currentTimeMillis();
	        		 WebPage pages = new WebPage(countIds++, url.toString(), contents, date);
	        		 dh.addWebPage(pages);
	        		 Log.d("Database after adding new page ", "Listing all pages..");
	  			     List<WebPage> list = dh.getAll();  
	  			     for (WebPage lr : list) {
	  			            String log = "ID:" + lr.getID() +" URL: " + lr.getUrl() + " Source: " + lr.getSource() + " Date: " + lr.getDate();
	  			            Log.d("Database after adding new page ", log); 
	  			     }
//	  			     dh.close();
	  			     Log.d("WebOff ", "New web page added to database");
				} catch (MalformedURLException e) {
				    Toast.makeText(getApplicationContext(), editText.getText().toString() +" is invalid URL, Please enter a valid URL address!", Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
        	}
        });
    }
    
    
    /**
	 * urlToString() take an URL and returns the content of the web page.
	 * 
	 * @param address
	 *            is the URL address
	 * @return the content of the URL address.
	 */
    private String urlToString(String address) {
		HttpURLConnection con = null;
		URL url;
		InputStream is = null;
		try {
			url = new URL(address);
			con = (HttpURLConnection) url.openConnection();
			con.setReadTimeout(10000);
			con.setConnectTimeout(15000);
			con.setRequestMethod("GET");
			con.connect();
			is = con.getInputStream();
		} catch (IOException e) {
			Log.v("log","dagjk");
			e.printStackTrace();
		}
		BufferedReader reader = null;
		StringBuilder sb = new StringBuilder();
		try {
			reader = new BufferedReader(new InputStreamReader(is));
			String line = "";
			while ((line = reader.readLine()) != null) {
				sb.append(line);
				Log.d("Content", line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return sb.toString();
	}
}
