package uk.ac.tees.L1087591;

/**
 * <p>Remove represent the remove functionality of the MenuActivity. It allows to delete an URL from the database</p>
 *
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */

import java.util.List;

import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class Remove extends MenuActivity {

	/**
	 * sca is an object of type SimpleCursorAdapter and we use it to set the
	 * adapter.
	 */
	private SimpleCursorAdapter sca;

	/**
	 * dh is an object of type DatabaseHandler and we use it to connet to the
	 * data base.
	 */
	private DatabaseHandler dh;

	/**
	 * mainListView is a List View.
	 */
	private ListView mainListView;

	/**
	 * context is a Content that takes the current one(this)
	 */
	private final Context context = this;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_remove);
		mainListView = (ListView) findViewById(R.id.mainListView);
		dh = new DatabaseHandler(this);

		/**
		 * cursor takes the arguments of the return value of getAllAsCursor.
		 */
		final Cursor cursor = dh.getAllAsCursor();

		/**
		 * cols gets the value of the COL_url
		 */
		String[] cols = new String[] { DatabaseHandler.COL_url };

		/**
		 * to get the value of the url_entry.
		 */
		int[] to = new int[] { R.id.url_entry };
		sca = new SimpleCursorAdapter(this, R.layout.complexrow, cursor, cols,
				to, 2);
		mainListView.setAdapter(sca);

		// when the list view is beign clicked
		mainListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int id,
					long arg3) {

				// delete the WebPage and list the rest of the database.
				dh.deletewebpage(id);
				Log.d("Database after deletion ", "Listing all pages..");
				List<WebPage> list = dh.getAll();
				for (WebPage lr : list) {
					String log = "ID:" + lr.getID() + " URL: " + lr.getUrl()
							+ " Source: " + lr.getSource() + " Date: "
							+ lr.getDate();
					Log.d("Database after deletion ", log);
				}
				Log.d("WebOff ", "Web page removed");
				cursor.close();
				Intent k = new Intent(context, Home.class);
				startActivity(k);
			}
		});
	}
}
