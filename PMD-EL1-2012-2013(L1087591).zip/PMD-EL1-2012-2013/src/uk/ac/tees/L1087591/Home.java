package uk.ac.tees.L1087591;

/**
 * <p>Home represent the starting page of the MenuActivity.</p>
 *
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.content.SharedPreferences;
import android.util.Log;

public class Home extends MenuActivity {

	/**
	 * appSharedPreferences is responsible for the sharedPreferences name.
	 */
	public static final String appSharedPreferences = "preferences";
	
	/**
	 * fileRead is responsible for reading the file
	 */
	public static final String fileRead = "readFile";

	/**
	 * url is responsible for the url of the web page.
	 */
	private String url;
	
	/**
	 * date is responsible for staring the last time the url was visited.
	 */
	private String date;
	
	/**
	 * content is responsible for storing the content of the web page.
	 */
	private String content;
	
	/**
	 * i represent the number of the web pages.
	 */
	private int i = 0;
	
	/**
	 * sb stores the content of the file pages.txt
	 */
	private StringBuilder sb;
	
	/**
	 * pages is a List that  stores the web pages.
	 */
	private List<WebPage> pages = new ArrayList<WebPage>();
	
	/**
	 * myDate store the date in type long
	 */
	private long myDate;
	
	/**
	 * id is responsible for the id of the web pages.
	 */
	private int id = 0;
	
	/**
	 * dh is a object of type DatabaseHandler that makes the connection with the database.
	 */
	private DatabaseHandler dh;
	
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);
		SharedPreferences sp = this.getSharedPreferences(
				Home.appSharedPreferences, Activity.MODE_PRIVATE);
		
		//if the file has been read go the the regularExpresionStrings method
		if (sp.getBoolean(Home.fileRead, true))
			regularExpresionStrings();

		Log.d("Database: ", " In Home..");
	}


	/**load() uses the file pages.txt which is in the .../raw/pages
	 * 
	 * @return the content of the file as a string
	 */
	private String load() {
		try {
			Log.d("Home", " in the load method");

			// final FileInputStream fis = openFileInput(filename);
			final InputStream fis = getResources().openRawResource(R.raw.pages);
			final BufferedReader reader = new BufferedReader(
					new InputStreamReader(fis));
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
			reader.close();
			fis.close();
			return sb.toString();
		} catch (Exception ex) {
			return "No entry exists for this file";
		}
	}

	/**regularExpresionStrings() splits the web pages and for each web page creates an object of type WebPage.
	 * 
	 * @return the content of the web pages
	 */
	private String regularExpresionStrings() {
		Log.d("Home", " in the regularExpresionStrings method");
		String content = load();
		String[] parts = content.split("</html>");
		String pa = "";
		for (int iter = 0; iter < parts.length; iter++) {
			pa = new String(parts[iter] + "</html>");
			Log.d("Page" + (i ++), pa);
			if (pa.contains("Address:")) {
				url = pa.substring(pa.indexOf("http"), pa.indexOf("html") + 4);
				Log.d("Address" + (i + 1), url);
			}
			if (pa.contains("Date:")) {
				date = pa.substring(pa.indexOf("Date:") + 5,
						pa.indexOf("Date:") + 18);
				myDate = Long.parseLong(date);
				Log.d("Date" + (i + 1), date);
			}
			content = pa.substring(pa.indexOf("<!DOCTYPE html>"),
					pa.indexOf("</html>"))
					+ "</html>";
			Log.d("Content" + (i + 1), content);
			WebPage webPages = new WebPage(id++, url, content, myDate);
			pages.add(webPages);
			System.out.println(webPages.toString());
			dh = new DatabaseHandler(this);
			dh.addWebPage(pages);
		}
		Log.d("WebOff", "File successfully imported");
		this.saveFileRead();
		Log.d("WebOff", "Number of Ids");
		return content;
	}

	/**
	 * saveFileRead check whether the file has already been read.
	 */
	private void saveFileRead() {
		SharedPreferences sp = this.getSharedPreferences(
				Home.appSharedPreferences, Activity.MODE_PRIVATE);
		SharedPreferences.Editor edi = sp.edit();
		edi.putBoolean(Home.fileRead, false);
		edi.commit();
	}

}
