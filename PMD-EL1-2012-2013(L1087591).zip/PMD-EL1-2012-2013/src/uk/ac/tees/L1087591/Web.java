package uk.ac.tees.L1087591;

/**
 * <p>Web pulls the data from the database and  displays the content of the website on the screen.
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */

import android.os.Bundle;
import android.util.Log;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;

public class Web extends MenuActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_web);

		/**
		 * webview represent a web view, where the text if going to be
		 * displayed.
		 */
		final WebView webview = (WebView) findViewById(R.id.webview);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings()
				.setLayoutAlgorithm(LayoutAlgorithm.NARROW_COLUMNS);

		/**
		 * dh is an object of type DatabaseHandler and is used to connect with
		 * the Database.
		 */
		DatabaseHandler dh = new DatabaseHandler(this);

		/**
		 * page stores the web page by Id.
		 */
		WebPage page = dh.getWebPage(Read.myId);

		/**
		 * log takes the content of the web page.
		 */
		String log = page.getSource();
		webview.loadDataWithBaseURL("http://nada", log, "text/html", "utf8", "");
		Log.d("WebOff ", "Reading page with WebOff");
	}

}
