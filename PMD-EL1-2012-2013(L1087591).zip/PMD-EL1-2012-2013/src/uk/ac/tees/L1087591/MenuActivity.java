package uk.ac.tees.L1087591;

/**
 * <p>MenuActivity extends Activity and provides alternative menu.</p>
 *
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;


public class MenuActivity extends Activity {


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}
	
	@Override
   	public boolean onOptionsItemSelected(MenuItem item) {
   		final Context context = this;
   		Intent i;
   		switch (item.getItemId()) {
   		case R.id.home:
   			i = new Intent(context, Home.class);  
   			startActivity(i);
   			return true;
   		case R.id.read:
   			i = new Intent(context, Read.class);  
   			startActivity(i);
   			return true;
   		case R.id.remove:
   			i = new Intent(context, Remove.class);  
   			startActivity(i);
   			return true;
   		case R.id.add:
   			i = new Intent(context, Add.class);  
   			startActivity(i);
   			return true;
   		case R.id.update:
   			i = new Intent(context, Update.class);  
   			startActivity(i);
   			return true;
   		default:
   			return super.onOptionsItemSelected(item);
   		}
   	}
	
	
}
