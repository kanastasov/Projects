package uk.ac.tees.L1087591;

/**
 * <p>DatabaseHandlery creates and manages a database containing WebPages. It
 * encapsulates all CRUD operations.</p>
 *
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */


import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DatabaseHandler extends SQLiteOpenHelper {
	
	/**
	 * The name of the database
	 */
	 protected static final String DATABASE_NAME = "Weboff.db";
	
	/**
	 * The name of the table.
	 */
	 protected static final String TABLE_NAME = "webpages";

	/**
	 * The name of the first column (ID)
	 */
	 protected static final String COL_ID = "_id";
	
	/**
	 * The name of the second column (URL)
	 */
	 protected static final String COL_url = "url";
	
	/**
	 * The name of the third column (source)
	 */
	 protected static final String COL_source = "source";
	
	 /**
	  * The name of the fourth column (date)
	  */
	 protected static final String COL_date = "date";

	/**
	 * A constructor which builds a DatabaseHandler object. Note that calling
	 * the constructor does not create a database. This does not happen until
	 * the first call to getReadableDatabase() or getWriteableDatabase()
	 * 
	 * @param context ,  In this case, a reference to webpageActivity
	 */
	public DatabaseHandler(Context context) {
		super(context, DATABASE_NAME, null, 1);
	}

	/**
	 * This method is called when the database is created for the first time.
	 * This is where the creation of tables and the initial population of the
	 * tables should happen.
	 */
	@Override
	public void onCreate(SQLiteDatabase db) {
		String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_NAME + "("
				+ COL_ID + " INTEGER PRIMARY KEY," + COL_url + " TEXT,"
				+ COL_source + " TEXT," + COL_date + " TEXT" + ");";
		Log.d("Table name in onCreate", TABLE_NAME);
		db.execSQL(CREATE_CONTACTS_TABLE);
		Log.d("WebOff", "Database populated");
	}

	/**
	 * Called when the database needs to be upgraded. Only relevant when you
	 * have multiple versions of the database scheme in play.
	 * 
	 */
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldNum, int newNum) {
		// Drop older table if exist and create fresh
		Log.w("Updating database: ", " Upgrading database from version " + oldNum
				+ " to "
				+ newNum + ", which will destroy all old data");
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
		onCreate(db);
	}

	/**
	 * Use this method to add a webpage to the database.
	 * 
	 * @param webpage
	 *            the webpage you want to add
	 */
	public void addWebPage(List<WebPage> webpage) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		for (WebPage lr : webpage) {
			values.put(COL_ID, lr.getID());
			values.put(COL_url, lr.getUrl());
			values.put(COL_source, lr.getSource());
			values.put(COL_date, lr.getDate());
        }
		db.insert(TABLE_NAME, null, values);
		db.close();
	}
	
	/**
	 * Use this method to add a webpage to the database.
	 * 
	 * @param webpage
	 *            the webpage you want to add
	 */
	public void addWebPage(WebPage webpage) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(COL_ID, webpage.getID());
		values.put(COL_url, webpage.getUrl());
		values.put(COL_source, webpage.getSource());
		values.put(COL_date, webpage.getDate());
		db.insert(TABLE_NAME, null, values);
		db.close();
	}

	/**
	 * Use this method to get all of the webpages in the database.
	 * 
	 * @return a list of webpage objects, one per row
	 */
	public List<WebPage> getAll() {
		List<WebPage> list = new ArrayList<WebPage>();
		String selectQuery = "SELECT  * FROM " + TABLE_NAME;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		
		WebPage webpage = null;
		
		if (cursor != null && cursor.moveToFirst()) {
			do {
				
				 webpage = new WebPage(cursor.getInt(0),
						cursor.getString(1), cursor.getString(2), cursor.getLong(3));
				list.add(webpage);
			} while (cursor.moveToNext());
			cursor.close();
		}
		
	    if (db != null) {
        db.close();
	    }
		
		return list;
	}

	
	/**
	 * Use this method to get a Cursor object that points at all the webpages in 
	 * the database
	 * 
	 * @return a Cursor object pointing at all webpages in db
	 */
	public Cursor getAllAsCursor() {
		String selectQuery = "SELECT  * FROM " + TABLE_NAME;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		return cursor;
	}
	
	/**
	 * Use this method to remove all of the webpages from the database. This is
	 * useful when experimenting. After dropping all tables, the initial state
	 * of the database is re-created.
	 */
	public void removeAll() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
		onCreate(db);
	}

	/**
	 * This method removes one webpage from the database.
	 * 
	 * @param webpage
	 *            the webpage to remove
	 */
	public void deletewebpage(int id) {
		SQLiteDatabase db = this.getWritableDatabase();
		
		db.delete(TABLE_NAME, COL_ID + " = ?",
				new String[] { String.valueOf(id)});
		db.close();
	}

	/**
	 * This method updates the data stored in the database for one webpage.
	 * 
	 * @param webpage
	 *            the webpage to update
	 * @return the number of rows affected
	 */
	public int updateWebPage(WebPage pages) {
			
			SQLiteDatabase db = this.getWritableDatabase();
			ContentValues values = new ContentValues();
//			values.put(COL_ID, lr.getID());
			values.put(COL_url, pages.getUrl());
			values.put(COL_source, pages.getSource());
			values.put(COL_date, pages.getDate());
			return db.update(TABLE_NAME, values, COL_ID + " = ?",
					new String[] { String.valueOf(((WebPage) pages).getID()) });
	}
	
	/**  
	 * This method gets a single webpage from the database, using the ID field
	 * as a key
	 * ;
	 * @param id
	 *            the ID of the webpage we want
	 * @return a webpage object
	 */
	public WebPage getWebPage(int id) {
	    SQLiteDatabase db = this.getReadableDatabase();
	    Cursor cursor = db.query(TABLE_NAME, new String[] { COL_ID, COL_url,
	            COL_source, COL_date }, COL_ID + "=?",
	            new String[] { String.valueOf(id) }, null, null, null, null);
	    WebPage webpage = null;
	    if (cursor != null && cursor.moveToFirst()) {
	        webpage = new WebPage(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getLong(3));
	        cursor.close();
	    }
	    if (db != null) {
	        db.close();
	    }
	    return webpage; // be aware, it might return null now!
	}
	
}

