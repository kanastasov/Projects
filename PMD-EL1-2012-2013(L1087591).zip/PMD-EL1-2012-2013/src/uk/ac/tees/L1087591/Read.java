package uk.ac.tees.L1087591;

/**
 * <p>Read represent the read functionality of the MenuActivity.</p>
 *
 * <p>This program is part of the solution for the first ICA for PMD in Teesside
 * University.</p>
 *
 * <p>PMD-EL1-2012-2013-SOLUTION is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.</p>
 *
 * <p>This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.</p>
 *
 * <p>You should have received a copy of the GNU General Public License along
 * with this program. If not, see http://www.gnu.org/licenses/.</p>
 *
 * <p>Copyright Kiril Anastasov L1087591@live.tees.ac.uk 12-Jan-2013 </p>
 */

import android.net.Uri;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class Read extends MenuActivity {

	/**
	 * sca is an object of type SimpleCursorAdapter and we use it to set the
	 * adapter.
	 */
	private SimpleCursorAdapter sca;

	/**
	 * dh is an object of type DatabaseHandler and we use it to connet to the
	 * data base.
	 */
	private DatabaseHandler dh;

	/**
	 * mainListView is a List View.
	 */
	private ListView mainListView;

	/**
	 * context is a Content that takes the current one(this)
	 */
	private final Context context = this;

	/**
	 * myId stores the id of the selected url
	 */
	protected static int myId;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_read);
		mainListView = (ListView) findViewById(R.id.mainListView);
		dh = new DatabaseHandler(this);

		/**
		 * Get a Cursor pointing at all web pages in the database
		 */
		final Cursor cursor = dh.getAllAsCursor();

		/**
		 * cols gets the value of the COL_url
		 */
		String[] cols = new String[] { DatabaseHandler.COL_url };

		/**
		 * to get the value of the url_entry.
		 */
		int[] to = new int[] { R.id.url_entry };
		sca = new SimpleCursorAdapter(this, R.layout.read, cursor, cols, to, 2);
		mainListView.setAdapter(sca);
		mainListView.showContextMenu();
		registerForContextMenu(mainListView);

		
		// when the user does a longclick
		mainListView.setOnItemLongClickListener(new OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int id, long arg3) {
				myId = id;
				Log.d("WebOff ",
						"Web page read:  id number in OnItemLongCLick " + id);
				cursor.close();
				return false;
			}
		});
		
	}
	
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		menu.setHeaderTitle("WebOff Menu");
		menu.add(0, v.getId(), 0, "Read using WebOff");
		menu.add(0, v.getId(), 0, "Read using web browser");
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		if (item.getTitle() == "Read using WebOff") {
			readUsingWebOff(item.getItemId());
		} else if (item.getTitle() == "Read using web browser") {
			readUsingWebBrowser(item.getItemId());
		} else {
			return false;
		}
		return true;
	}

	/**
	 * readUsingWebOff goes to the Web activity.
	 * 
	 * @param id
	 *            of the web Page
	 */
	public void readUsingWebOff(int id) {
		Toast.makeText(this, "WebOff called", Toast.LENGTH_SHORT).show();
		Intent k = new Intent(context, Web.class);
		startActivity(k);
	}

	/**
	 * readUsingWebBrowser() reads the web pages through the web broweser.
	 * 
	 * @param id
	 *            of the web page.
	 */
	public void readUsingWebBrowser(int id) {
		Toast.makeText(this, "Web browser called", Toast.LENGTH_SHORT).show();
		WebPage page = dh.getWebPage(Read.myId);
		String myUrl = 
//				"http://www.facebook.com";
				page.getUrl();
		Uri uri 
		= Uri.parse(myUrl);
		
//		dh.close();
		
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		startActivity(intent);
	}

}
