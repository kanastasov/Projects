I believe, that I  have done tasks 1-9 included.
There are no extre features and I haven't tested
the Application in the Linux lab. However it is 
working on a windows machine. 
I also have an extension for one week
till 1/14/2013 
Enjoy!