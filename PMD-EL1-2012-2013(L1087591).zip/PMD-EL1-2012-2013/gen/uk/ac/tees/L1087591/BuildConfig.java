/** Automatically generated file. DO NOT MODIFY */
package uk.ac.tees.L1087591;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}